package com.example.tictactoe;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;

import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Button btn;

    @FXML
    private HBox hbox;

    @FXML
    private Line hiba_1;

    @FXML
    private Circle c_hiba_2;

    @FXML
    private Line hiba_2;

    @FXML
    private Line hiba_3;

    @FXML
    private Line hiba_4;

    @FXML
    private Line hiba_5;

    @FXML
    private Line hiba_6;

    @FXML
    private Line hiba_7;

    @FXML
    private Label lbl_betuk;

    @FXML
    private Label lbl_end;

    @FXML
    private TextField tfield;

    String valasztottszo = "";
    ArrayList<Label> labels = new ArrayList<>();

    ArrayList<Line> hibak = new ArrayList<>();

    int hibakSzama = 0;
    boolean isGameOn = true;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        hiba_1.setVisible(false);hibak.add(hiba_1);
        c_hiba_2.setVisible(false);hibak.add(hiba_2);
        hiba_3.setVisible(false);hibak.add(hiba_3);
        hiba_4.setVisible(false);hibak.add(hiba_4);
        hiba_5.setVisible(false);hibak.add(hiba_5);
        hiba_6.setVisible(false);hibak.add(hiba_6);
        hiba_7.setVisible(false);hibak.add(hiba_7);

        ArrayList<String> szavak = new ArrayList<>(Arrays.asList("fika", "alma", "rajmund", "inantsy"));

        Collections.shuffle(szavak);
        valasztottszo = szavak.get(0);
        lbl_betuk.setText("A szó hossza : "+valasztottszo.length());

        System.out.println(valasztottszo);

        for (int i = 0; i < valasztottszo.length();i++){
            Label l = new Label("_");
            l.setId("betuk-label");
            labels.add(l);
            hbox.getChildren().add(l);
        }

    }


    @FXML
    void proba(ActionEvent event) {

        probaa();nyeres();vesztes();
        tfield.setText("");
    }

    @FXML
    void enter(KeyEvent event) {
        if( event.getCode() == KeyCode.ENTER ) {
            probaa();nyeres();vesztes();
            tfield.setText("");
        }
    }


    void nyeres(){
        int x = 0;
        for (int i = 0; i < valasztottszo.length();i++){
            if (String.valueOf(valasztottszo.charAt(i)).equals(labels.get(i).getText())){
                x+=1;
            }
        }
        if (x == valasztottszo.length()){
            lbl_end.setText("Nyertél haversrác!!");
            isGameOn = false;
        }
    }

    void vesztes(){
        if (hibakSzama == 7){
            lbl_end.setText("KIKAPTAL HAVERDA");
            isGameOn = false;
        }
    }

    void probaa(){
        if (isGameOn && !tfield.getText().isEmpty()){
            for (int i = 0; i < valasztottszo.length(); i++){
                if (tfield.getText().charAt(0) == valasztottszo.charAt(i)){
                    labels.get(i).setText(String.valueOf(valasztottszo.charAt(i)));
                }
            }
            if (!valasztottszo.contains(String.valueOf(tfield.getText()))){
                if (hibakSzama == 1){
                    c_hiba_2.setVisible(true);
                }
                hibak.get(hibakSzama).setVisible(true);
                hibakSzama += 1;
            }
        }
    }




}
