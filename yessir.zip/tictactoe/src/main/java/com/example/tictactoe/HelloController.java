package com.example.tictactoe;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Button btn;

    @FXML
    private HBox hbox;

    @FXML
    private Line hiba_1;

    @FXML
    private Circle hiba_2;

    @FXML
    private Line hiba_3;

    @FXML
    private Line hiba_4;

    @FXML
    private Line hiba_5;

    @FXML
    private Line hiba_6;

    @FXML
    private Line hiba_7;

    @FXML
    private Label lbl_betuk;

    @FXML
    private Label lbl_end;

    @FXML
    private TextField tfield;

    String valasztottszo = "";
    ArrayList<Label> labels = new ArrayList<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        hiba_1.setVisible(false);
        hiba_2.setVisible(false);
        hiba_3.setVisible(false);
        hiba_4.setVisible(false);
        hiba_5.setVisible(false);
        hiba_6.setVisible(false);
        hiba_7.setVisible(false);

        ArrayList<String> szavak = new ArrayList<>(Arrays.asList("Fika", "Alma", "Rajmund", "Inantsy"));

        Collections.shuffle(szavak);
        valasztottszo = szavak.get(0);
        System.out.println(valasztottszo);
        for (int i = 0; i < valasztottszo.length();i++){
            Label l = new Label("");
            l.setId("betuk-label");
            labels.add(l);
            hbox.getChildren().add(l);
        }

    }


    @FXML
    void proba(ActionEvent event) {

        for (int i = 0; i < valasztottszo.length(); i++){
            System.out.println(valasztottszo.charAt(i));
            if (tfield.getText().charAt(0) == valasztottszo.charAt(i)){
                //System.out.println(valasztottszo.charAt(i));
                labels.get(i).setText(String.valueOf(valasztottszo.charAt(i)));
            }
        }

    }

}
